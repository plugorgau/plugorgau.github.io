#! /bin/sh

some_function ()
{
    if [ "$1" = "$2" ]; then
	# return error
	return 1
    else
	# return success
	return 0
    fi
}

some_function "hi" "there" && echo "hi and there are different" || echo "foo and foo are the same"

some_function "fooo" "fooo" && echo "foo and foo are different" || echo "foo and foo are the same"



