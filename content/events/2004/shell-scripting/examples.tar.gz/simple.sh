#! /bin/sh
# this is a comment
ls -l
echo "hello world"
