#! /bin/sh

if [ "$#" != "1" ]; then
    echo "I want exactly one argument."
    exit
fi

if [ "$1" = "hi" ]; then
    echo "hello to you too"
else
    echo "boo"
fi
