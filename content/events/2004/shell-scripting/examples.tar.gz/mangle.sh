#! /bin/sh

# set -e

do_file ()
{
    cat \
	| sed 's,^\*\*\* \(.*\)$,<h2>\1</h2>,g' \
	| sed 's,^$,<p>,g' \
	| sed 's,\*\([a-zA-Z0-9]\+\)\*,<b>\1</b>,g' \
	| sed 's,/\([a-zA-Z0-9]\+\)/,<i>\1</i>,g' \
	| sed '1s,^Title: \(.*\),<html><head><title>\1</title></head>\n<body><h1>\1</h1>,g' \
	| sed '$a</body></html>' \
	| sed '/^#/ d'
}

cp file.doesnt.exist somewhere

if [ "$#" = "0" ]; then
    do_file
else
    for file in "$@"; do
	output="`basename $file .txt`.html"
	echo "processing $file to produce $output"
	do_file <${file} >${output}
    done
fi

