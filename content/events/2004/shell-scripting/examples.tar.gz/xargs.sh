#! /bin/sh
# simple examples of find and xargs

# from grab-photos.sh:
#     find . -maxdepth 1 -type f -name '*.jpg' -exec ./rotate-photos.sh \{\} \;

find tmp -name '*.sh' | xargs ls -l
# same as:
#   find tmp -name '*.sh' -exec ls -l \{\} \;
# but doesn't call ls more times than it needs to

(cd tmp; find . -type d) | (cd tmp2; xargs  mkdir -p)
# re-create the directory structure of tmp/ under tmp2/

