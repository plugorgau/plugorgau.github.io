#! /bin/sh
# Rotate photos using EXIF data from the camera
#

set -e

if jhead "$1" | grep -q '^Orientation.*90'; then
    echo "$1: Rotate 90"
    jpegtran -optimize -rotate 90 -copy all $1 >$1.tmp.$$ && mv $1.tmp.$$ $1
elif jhead "$1" | grep -q '^Orientation.*270'; then
    echo "$1: Rotate 270"
    jpegtran -optimize -rotate 270 -copy all $1 >$1.tmp.$$ && mv $1.tmp.$$ $1
else
    echo "$1: don't rotate"
fi

