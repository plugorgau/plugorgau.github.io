#! /bin/sh
# grab-photos.sh: download photos from a digital camera

DOWNLOAD="${HOME}/projects/plug/shell-scripts/photos/`date '+%Y-%m-%d_%H-%M'`"

[ -d "$DOWNLOAD" ] || mkdir -p "$DOWNLOAD"

if [ -d "$DOWNLOAD" ]; then
    cd "$DOWNLOAD" || exit 1
    (echo "*** `date`" && 
	gphoto2 -P 2>&1 && 
	gphoto2 -D 2>&1 &&
	echo) | tee images.log
    jhead -n"%m%d-%H%M" *.[Jj][Pp][Gg]
    find . -maxdepth 1 -type f -name '*.jpg' -exec ${HOME}/projects/plug/shell-scripts/rotate-photos.sh \{\} \;
    echo
    echo "Photos downloaded to $DOWNLOAD"
fi
