#! /bin/sh
# vars.sh: really trivial example of shell variables

MESSAGE="hello there"

echo "$MESSAGE"
echo "$MESSAGE $1"
echo "$MESSAGEfoo"
echo "${MESSAGE}foo"

echo "I have $# arguments"

